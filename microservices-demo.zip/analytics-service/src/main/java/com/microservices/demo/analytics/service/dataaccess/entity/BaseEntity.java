package com.microservices.demo.analytics.service.dataaccess.entity;

public interface BaseEntity<PK> {
    PK getId();
}
