package com.microservices.demo.reactive.elastic.query.web.client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ReactiveElasticQueryWebClientApplicationTests {

    @Test
    public void contextLoads() {
    }

}
